#include <omp.h>
#include "common.h"
#include <cmath>
#include <algorithm>

struct ParticleContainer;
struct ParticleContainerPredecessor;
struct ParticleContainerPredecessor {
    ParticleContainer* next = nullptr;
};
struct ParticleContainer : ParticleContainerPredecessor {
    ParticleContainerPredecessor* prev = nullptr;
    particle_t* p = nullptr;
    int g_i;
};
ParticleContainerPredecessor* particle_grid;
ParticleContainer* particle_containers;
omp_lock_t* g_locks;

static void inline __attribute__((always_inline))
linkParticle(ParticleContainerPredecessor* pred, ParticleContainer* pc) {
    pc->prev = pred;
    pc->next = pred->next;
    if (pred->next != nullptr)
        pred->next->prev = pc;
    pred->next = pc;
}

static void inline __attribute__((always_inline))
unlinkParticle(ParticleContainer* pc) {
    pc->prev->next = pc->next;
    if (pc->next != nullptr)
        pc->next->prev = pc->prev;
}

const double grid_step = cutoff*1.0001;
int g_lda;

// Apply the force from neighbor to particle
static void inline __attribute__((always_inline))
apply_force(particle_t* particle, particle_t* neighbor) {
    // Calculate Distance
    double dx = neighbor->x - particle->x;
    double dy = neighbor->y - particle->y;
    double r2 = dx * dx + dy * dy;

    // Check if the two particles should interact
    if (r2 > cutoff * cutoff)
        return;

    r2 = std::max(r2, min_r * min_r);
    double r = sqrt(r2);

    // Very simple short-range repulsive force
    double coef = (1 - cutoff / r) / r2 / mass;
    particle->ax += coef * dx;
    particle->ay += coef * dy;
//    neighbor->ax -= coef * dx;
//    neighbor->ay -= coef * dy;
}

static void inline __attribute__((always_inline))
apply_intercell_force(particle_t* const p, const int i_prime) {
    for(ParticleContainer* pc_prime = particle_grid[i_prime].next; pc_prime != nullptr; pc_prime = pc_prime->next) {
        particle_t* p_prime = pc_prime->p;
        apply_force(p, p_prime);
    }
}

// Integrate the ODE
static void inline __attribute__((always_inline))
move(particle_t* p, double size) {
    // Slightly simplified Velocity Verlet integration
    // Conserves energy better than explicit Euler method
    p->vx += p->ax * dt;
    p->vy += p->ay * dt;
    p->x += p->vx * dt;
    p->y += p->vy * dt;

    // Bounce from walls
    while (p->x < 0 || p->x > size) {
        p->x = p->x < 0 ? -p->x : 2 * size - p->x;
        p->vx = -p->vx;
    }

    while (p->y < 0 || p->y > size) {
        p->y = p->y < 0 ? -p->y : 2 * size - p->y;
        p->vy = -p->vy;
    }
}


void init_simulation(particle_t* parts, int num_parts, double size) {
    // You can use this space to initialize static, global data objects
    // that you may need. This function will be called once before the
    // algorithm begins. Do not do any particle simulation here
    g_lda = static_cast<int>(floor(size/grid_step))+1+2;
    particle_grid = new ParticleContainerPredecessor[g_lda*g_lda]();
    particle_containers = new ParticleContainer[num_parts]();
    g_locks = new omp_lock_t[g_lda*g_lda]();
    for (int g_i = 0; g_i < g_lda*g_lda; ++g_i)
        omp_init_lock(g_locks+g_i);
    for (int p_i = 0; p_i < num_parts; ++p_i) {
        ParticleContainer* pc = particle_containers+p_i;
        particle_t* p = parts+p_i;
        pc->p = p;
        p->ax = p->ay = 0;
        int g_x = static_cast<int>(floor(p->x/grid_step))+1;
        int g_y = static_cast<int>(floor(p->y/grid_step))+1;
        int g_i = g_y+g_lda*g_x;
        pc->g_i = g_i;
        ParticleContainerPredecessor* g = particle_grid+g_i;
        linkParticle(g, pc);
    }
}

void simulate_one_step(particle_t* parts, int num_parts, double size) {
    int tn = omp_get_thread_num();
    int tN = omp_get_num_threads();
    // Compute Forces
    int stride = std::max(3, (g_lda-2+tN-1)/tN);
    for (int j = 1+tn*stride; j < 1+(tn+1)*stride && j < g_lda-1; ++j) {
      for (int k = 1; k < g_lda-1; ++k) {
        int i = g_lda*j+k;
        for (ParticleContainer* pc = particle_grid[i].next; pc != nullptr; pc = pc->next) {
            particle_t* p = pc->p;
            apply_intercell_force(p, i-g_lda-1);
            apply_intercell_force(p, i-g_lda);
            apply_intercell_force(p, i-g_lda+1);
            apply_intercell_force(p, i-1);
            apply_intercell_force(p, i);
            apply_intercell_force(p, i+1);
            apply_intercell_force(p, i+g_lda-1);
            apply_intercell_force(p, i+g_lda);
            apply_intercell_force(p, i+g_lda+1);
//            for (ParticleContainer* pc_prime = pc->next; pc_prime != nullptr; pc_prime = pc_prime->next)
//                apply_force(p, pc_prime->p);
        }
      }
    }
    #pragma omp barrier
    // Move Particles
    #pragma omp for schedule(static,1024*4)
    for (int p_i = 0; p_i < num_parts; ++p_i) {
        ParticleContainer* pc = particle_containers+p_i;
        particle_t* p = pc->p;
        move(p, size);
        p->ax = p->ay = 0;
        int g_x_prime = static_cast<int>(p->x/grid_step)+1;
        int g_y_prime = static_cast<int>(p->y/grid_step)+1;
        int g_i_prime = g_y_prime+g_lda*g_x_prime;
        if (pc->g_i != g_i_prime) {
            ParticleContainerPredecessor* g_prime = particle_grid+g_i_prime;
            omp_set_lock(g_locks+pc->g_i);
            omp_set_lock(g_locks+g_i_prime);
            unlinkParticle(pc);
            linkParticle(g_prime, pc);
            omp_unset_lock(g_locks+g_i_prime);
            omp_unset_lock(g_locks+pc->g_i);
            pc->g_i = g_i_prime;
        }
    }
    #pragma omp barrier
}
